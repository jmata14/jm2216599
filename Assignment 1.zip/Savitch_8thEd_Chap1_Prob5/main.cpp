/* 
 * File:   main.cpp
 * Author: Jesus Mata
 * Created on January 12, 2014, 10:18PM
 * Find the sum and product
 * of two integers.
 */

//System Libraries
#include <iostream>
using namespace std;

//Global Constants

//Function Prototypes

//Execution Begins Here!
int main( ){
    //Declare Variables
    int number1, number2, sum, product;
    //Input first number
    cout << "Press return after entering a number.\n";
    cout << "Enter the first number:\n";
    cin >> number1;
    //Input second number
    cout << "Enter the second number:\n";
    cin >> number2;
    //Calculate sum
    sum = number1 + number2;
    product = number1 * number2;
    //Output sum
    cout << "The sum is: ";
    cout << sum;
    cout << ".\n";
    cout << "The product is: ";
    cout << product;
    cout << ".\n";
    //Exit stage right      
    return 0;
}

