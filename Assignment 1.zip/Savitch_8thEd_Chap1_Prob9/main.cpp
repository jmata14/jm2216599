/* 
 * File:   main.cpp
 * Author: Jesus Mata
 * Created on January 12, 2014, 10:19PM
 * Calculate the distance an object will
 * travel given the time, in seconds, 
 * of freefall.
 */

//System Libraries
#include <iostream>
#include <cmath>
using namespace std;

//Global Constants
const float GRV=32; //Acceleration due to gravity in ft/sec

//Function Prototypes

//Execution Begins Here!
int main(int argc, char** argv) {
    //Declare variables
    int dfeet, time;
    //Input time of freefall
    cout<<"How many seconds is the object in freefall?\n";
    cin>>time;
    //Calculate distance traveled
    dfeet=(GRV*pow(time,2))/2;
    //Output distance traveled
    cout<<"The distance traveled is: ";
    cout<<dfeet;
    cout<<" feet.\n";
    //Exit stage right
    return 0;
}

