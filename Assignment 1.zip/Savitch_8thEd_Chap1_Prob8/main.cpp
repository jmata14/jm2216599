/* 
 * File:   main.cpp
 * Author: Jesus Mata
 * Created on January 12, 2014, 10:19PM
 * Find the sum, in cents, given the 
 * number of quarters, dimes, and nickels.
 */

//System Libraries
#include <iostream>
using namespace std;

//Global Constants

//Function Prototypes

//Execution Begins Here!
int main( ){
    //Declare variables
    int quarter, dime, nickel, sum;
    //Input the number of quarters
    cout << "Press return after entering a number.\n";
    cout << "Enter the number of quarters.\n";
    cin >> quarter;
    //Input the number of dimes
    cout << "Enter the number of dimes.\n";
    cin >> dime;
    //Input the number of nickels
    cout << "Enter the number of nickels.\n";
    cin >> nickel;
    //Calculate the sum
    sum = (quarter * 25) + (dime * 10) + (nickel * 5);
    //Output the sum
    cout << "The sum is: ";
    cout << sum;
    cout << " cents.\n";
    //Exit stage right      
    return 0;
}

