/* 
 * File:   main.cpp
 * Author: Jesus Mata
 * Created on January 12, 2014, 10:18PM
 * Create and record errors 
 * from Problem 4 and Problem 6
 */

nbproject/Makefile-Debug.mk:66: recipe for target 'build/Debug/Cygwin_4.x-Windows/main.o' failed
make[2]: *** [build/Debug/Cygwin_4.x-Windows/main.o] Error 1
make[2]: Leaving directory '/cygdrive/c/Users/JeSnA/Documents/NetBeansProjects/Ch1 Problem4'
nbproject/Makefile-Debug.mk:59: recipe for target '.build-conf' failed
make[1]: *** [.build-conf] Error 2
make[1]: Leaving directory '/cygdrive/c/Users/JeSnA/Documents/NetBeansProjects/Ch1 Problem4'
nbproject/Makefile-impl.mk:39: recipe for target '.build-impl' failed
make: *** [.build-impl] Error 2
    
        
        
"/usr/bin/make" -f nbproject/Makefile-Debug.mk QMAKE= SUBPROJECTS= .build-conf
make[1]: Entering directory '/cygdrive/c/Users/JeSnA/Documents/NetBeansProjects/Ch1 Problem5'
"/usr/bin/make"  -f nbproject/Makefile-Debug.mk dist/Debug/Cygwin_4.x-Windows/ch1_problem5.exe
make[2]: Entering directory '/cygdrive/c/Users/JeSnA/Documents/NetBeansProjects/Ch1 Problem5'
mkdir -p build/Debug/Cygwin_4.x-Windows
rm -f "build/Debug/Cygwin_4.x-Windows/main.o.d"
g++    -c -g -MMD -MP -MF "build/Debug/Cygwin_4.x-Windows/main.o.d" -o build/Debug/Cygwin_4.x-Windows/main.o main.cpp
main.cpp:10:21: fatal error:  iostream: No such file or directory
 #include < iostream>
                     ^
compilation terminated.
nbproject/Makefile-Debug.mk:66: recipe for target 'build/Debug/Cygwin_4.x-Windows/main.o' failed
make[2]: *** [build/Debug/Cygwin_4.x-Windows/main.o] Error 1
make[2]: Leaving directory '/cygdrive/c/Users/JeSnA/Documents/NetBeansProjects/Ch1 Problem5'
nbproject/Makefile-Debug.mk:59: recipe for target '.build-conf' failed
make[1]: *** [.build-conf] Error 2
make[1]: Leaving directory '/cygdrive/c/Users/JeSnA/Documents/NetBeansProjects/Ch1 Problem5'
nbproject/Makefile-impl.mk:39: recipe for target '.build-impl' failed
make: *** [.build-impl] Error 2