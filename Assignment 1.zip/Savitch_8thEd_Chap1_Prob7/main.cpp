/* 
 * File:   main.cpp
 * Author: Jesus Mata
 * Created on January 12, 2014, 10:19PM
 * Output "CS!" in large 
 * block letters.
 */

//System Libraries
#include <iostream>
using namespace std;

//Global Constants

//Function Prototypes

//Execution Begins Here!
int main( ){
    //Create output
    cout << "************************************\n";
    cout << "\n";
    cout << "     C C C          S S S S      !!\n";
    cout << "   C       C      S         S    !!\n";
    cout << "  C              S               !!\n";
    cout << " C                S              !!\n";
    cout << " C                 S S S S       !!\n";
    cout << " C                          S    !!\n";
    cout << "  C                          S   !!\n";
    cout << "   C       C      S         S      \n";
    cout << "     C C C          S S S S      00\n";
    cout << "\n";
    cout << "************************************\n";
    cout << "\n";
    cout << "\n";
    cout << " Computer Science is Cool Stuff!!!\n";
    //Exit stage right         
    return 0;
}

