/* 
 * File:   main.cpp
 * Author: Jesus Mata
 * Created on January 12, 2014, 10:20PM
 * Output a large block letter "C"
 * composed of the character inputted 
 * from the keyboard.
 */

//System Libraries
#include <iostream>
using namespace std;

//Global Constants

//Function Prototypes

//Execution Begins Here!
int main(int argc, char** argv) {
    //Declare variables
    char letter;
    //Input the character
    cout<<"What letter would you like to use?";
    cin>>letter;
    //Output block letter "C"
    cout<<"  "<<letter<<" "<<letter<<" "<<letter<<"\n";
    cout<<" "<<letter<<"    "<<letter<<"\n";
    cout<<letter<<"\n";
    cout<<letter<<"\n";
    cout<<letter<<"\n";
    cout<<letter<<"\n";
    cout<<letter<<"\n";
    cout<<" "<<letter<<"    "<<letter<<"\n";
    cout<<"  "<<letter<<" "<<letter<<" "<<letter<<"\n";
    //Exit stage right
    return 0;
}

