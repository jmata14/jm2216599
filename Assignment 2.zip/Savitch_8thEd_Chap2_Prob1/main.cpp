/* 
 * File:   main.cpp
 * Author: Jesus Mata
 * Created on January 19, 2014, 9:30 PM
 * Input package weight in ounces,
 * output weight in metric tons
 * and the number of boxes needed 
 * to yield one ton.
 */

//System Libraries
#include <iostream>
using namespace std;

//Global Constants
const double CNV_OZ_TON=1/35273.92;

//Function Prototypes

//Execution begins here!
int main(int argc, char** argv){
    //Declare variables
    float cereal_oz, weight_ton, boxes_in_ton;
    //Input package weight
    cout<<"How many ounces is the cereal package?\n";
    cin>>cereal_oz;
    //Convert to tons
    weight_ton=cereal_oz*CNV_OZ_TON;
    cout<<"The package is "<<weight_ton<<" tons.\n";
    //Calculate boxes needed to yield one ton
    boxes_in_ton=1/weight_ton;
    cout<<"The number of cereal boxes needed to yield\n";
    cout<<"one ton is: "<<boxes_in_ton<<endl;
    //Exit stage right
    return 0;
}

