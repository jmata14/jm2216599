/* 
 * File:   main.cpp
 * Author: Jesus Mata
 * Created on January 22, 2014, 9:04 AM
 * Gauge the expected cost of an item
 * in specified number of years.
 */

//System Libraries
#include <iostream>
#include <iomanip>
using namespace std;

//Global Constants
const float CNV_PERC=100;

//Function Prototypes

//Execution begins here!
int main(int argc, char** argv){
    //Declare Variables
    float price, infltn;
    //Input price
    cout<<"Input the starting price "
        <<"of an item in $"<<endl;
    cin>>price;
    cout<<"Input the inflation rate "
        <<"over time in %"<<endl;
         cin>>infltn;
    //Adjust
         infltn/=CNV_PERC;
    //Calculate the first years increase
         price*=(1+infltn);
    //Output
         cout.setf(ios::fixed);
         cout.setf(ios::showpoint);
         cout.precision(2);
         cout<<"Price increase "
             <<"first year = $"
             <<price<<endl;
    //Calculate the second years increase
         price*=(1+infltn);
    //Output
         cout<<"Price increase "
             <<"second year = $"
             <<price<<endl;
    //Calculate the third years increase
         price*=(1+infltn);
    //Output
         cout<<"Price increase "
             <<"third year = $"
             <<price<<endl;
    //Exit Stage Right
    return 0;
}


