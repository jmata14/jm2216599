/* 
 * File:   main.cpp
 * Author: Jesus Mata
 * Created on January 21, 2014, 8:31 PM
 * Determine whether a meeting room 
 * meets fire regulations based on the
 * number of people in the room
 * and determine the number of people 
 * under or over capacity.
 */

//System Libraries
#include <iostream>
using namespace std;

//Global Constants

//Function Prototypes

//Execution begins here!
int main(int argc, char** argv){
    //Declare variables
    int max_cap, num_ppl;
    cout<<"What is the maximum number of people allowed?\n";
    cin>>max_cap;
    cout<<"How many people are in the room.\n";
    cin>>num_ppl;
    if(num_ppl<=max_cap){
        cout<<"It is legal to hold the meeting.\n";
        cout<<max_cap%num_ppl<<" more people are allowed to "
            <<"sttend the meeting\n";
    }
    else{
        cout<<"The meeting cannot be held as planned "
            <<"due to fire regulations.\n";
        cout<<num_ppl%max_cap<<" people must be excluded in "
            <<"order to meet fire regulations.\n";
    }
    //Exit stage right
    return 0;
}



