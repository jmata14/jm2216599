/* 
 * File:   main.cpp
 * Author: Jesus Mata
 * Created on January 22, 2014, 9:26 AM
 */

//System Libraries
#include <iostream>
using namespace std;

//Global Constants

//Function Prototypes

//Execution begins here!
int main(int argc, char** argv){
    //Declare variables
    int num1,num2,num3,num4,num5,num6,num7,num8,num9,num10,
        pos_tally=0, neg_tally=0, tot_tally=0;
    //Input ten numbers
    cout<<"Input ten whole numbers.\n";
    cin>>num1>>num2>>num3>>num4>>num5>>num6>>num7>>num8>>num9>>num10;
    if(num1<0){
        neg_tally+=num1;
        tot_tally+=num1;
    }
    else{
        pos_tally+=num1;
        tot_tally+=num1;
    }
    if(num2<0){
        neg_tally+=num2;
        tot_tally+=num2;
    }
    else{
        pos_tally+=num2;
        tot_tally+=num2;
    }
    if(num3<0){
        neg_tally+=num3;
        tot_tally+=num3;
    }
    else{
        pos_tally+=num3;
        tot_tally+=num3;
    }
    if(num4<0){
        neg_tally+=num4;
        tot_tally+=num4;
    }
    else{
        pos_tally+=num4;
        tot_tally+=num4;
    }
    if(num5<0){
        neg_tally+=num5;
        tot_tally+=num5;
    }
    else{
        pos_tally+=num5;
        tot_tally+=num5;
    }
    if(num6<0){
        neg_tally+=num6;
        tot_tally+=num6;
    }
    else{
        pos_tally+=num6;
        tot_tally+=num6;
    }
    if(num7<0){
        neg_tally+=num7;
        tot_tally+=num7;
    }
    else{
        pos_tally+=num7;
        tot_tally+=num7;
    }
    if(num8<0){
        neg_tally+=num8;
        tot_tally+=num8;
    }
    else{
        pos_tally+=num8;
        tot_tally+=num8;
    }
    if(num9<0){
        neg_tally+=num9;
        tot_tally+=num9;
    }
    else{
        pos_tally+=num9;
        tot_tally+=num9;
    }
    if(num10<0){
        neg_tally+=num10;
        tot_tally+=num10;
    }
    else{
        pos_tally+=num10;
        tot_tally+=num10;
    }
    cout<<"The positive tally is "<<pos_tally<<endl;
    cout<<"The negative tally is "<<neg_tally<<endl;
    cout<<"The total tally is "<<tot_tally<<endl;
    //Exit stage right
    return 0;
}


