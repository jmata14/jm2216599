/* 
 * File:   main.cpp
 * Author: Jesus Mata
 * Created on January 21, 2014, 6:40 PM
 * Calculate the face value of a loan 
 * given the amount the consumer needs,
 * the interest rate, and the duration 
 * of the loan in months.
 */

//System Libraries
#include <iostream>
using namespace std;

//Global Constants
const double CNV_MO_YR=0.0833333, CNV_PRC_FRCT=0.01;

//Function Prototypes

//Execution begins here!
int main(int argc, char** argv){
    //Declare variables
    float amnt_ndd, int_rate, lon_drtn, fce_vlu, mnth_pym;
    //Input
    cout<<"How much money do you need?\n";
    cin>>amnt_ndd;
    //Input
    cout<<"What is the interest rate?\n";
    cin>>int_rate;
    //Input
    cout<<"What is the duration of the loan in months?\n";
    cin>>lon_drtn;
    //Calculate face value
    fce_vlu=amnt_ndd/(1-(int_rate*CNV_PRC_FRCT*lon_drtn*CNV_MO_YR));
    //Set number of digits after decimal point
    cout.setf(ios::fixed);
    cout.setf(ios::showpoint);
    cout.precision(2);
    //Output face value 
    cout<<"The face value of the loan is "<<fce_vlu<<endl;
    //Exit stage right
    return 0;
}


