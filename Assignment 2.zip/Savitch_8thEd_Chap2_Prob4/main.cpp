/* 
 * File:   main.cpp
 * Author: Jesus Mata
 * Created on January 21, 2014, 6:22 PM
 * Determine retroactive pay 
 * after 7.6% increase in salary for 
 * the number of months requested.
 */

//System Libraries
#include <iostream>
using namespace std;

//Global Constants

//Function Prototypes

//Execution begins here!
int main(int argc, char** argv){
    //Declare variables
    const float pay_increase=.076;
    int annual_salary, monthly_salary, number_months, retro_pay;
    //Input annual salary
    cout<<"What is the previous years annual salary?\n";
    cin>>annual_salary;
    //Determine monthly salary
    monthly_salary=annual_salary/12;
    //Input number of months to be paid retroactively
    cout<<"For how many months do you want retroactive pay?";
    cin>>number_months;
    //Calculate retroactive pay
    retro_pay=number_months*monthly_salary*pay_increase;
    //Set number of digits after decimal point
    cout.setf(ios::fixed);
    cout.setf(ios::showpoint);
    cout.precision(2);
    //Output retroactive pay
    cout<<"Retroactive pay due for the previous "<<number_months
        <<" month(s) is "<<(annual_salary*pay_increase)/2<<endl;
    //Exit stage right
    return 0;
}




