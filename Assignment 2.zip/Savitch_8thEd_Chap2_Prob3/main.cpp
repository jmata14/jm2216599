/* 
 * File:   main.cpp
 * Author: Jesus Mata
 * Created on January 21, 2014, 6:03 PM
 * Determine retroactive pay
 * for the previous six months
 * after 7.6% increase in salary.
 */

//System Libraries
#include <iostream>
using namespace std;

//Global Constants

//Function Prototypes

//Execution begins here!
int main(int argc, char** argv){
    //Declare variables
    const float pay_increase=.076;
    int annual_salary;
    cout<<"What is the previous years annual salary?\n";
    cin>>annual_salary;
    cout.setf(ios::fixed);
    cout.setf(ios::showpoint);
    cout.precision(2);
    cout<<"Retroactive pay due for the previous six months is: "
        <<(annual_salary*pay_increase)/2<<endl;
    //Exit stage right
    return 0;
}



