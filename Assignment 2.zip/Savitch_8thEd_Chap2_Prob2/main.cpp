/* 
 * File:   main.cpp
 * Author: Jesus Mata
 * Created on January 19, 2014, 10:27 PM
 * How much diet soda is it possible
 * to drink without dying?
 */

//System Libraries
#include <iostream>
using namespace std;

//Global Constants

//Function Prototypes

//Execution begins here!
int main(int argc, char** argv){
    //Declare variables
    const float swtnr_pct=0.001;
    double swtnr_kill_mouse, wgt_mouse, wgt_dieter,
          lethal_ratio_mouse, lethal_ratio_person, diet_soda;
    //Input sweetener needed to kill mouse
    cout<<"How many ounces of sweetener is needed to kill a mouse?\n";
    cin>>swtnr_kill_mouse;
    //Input weight of mouse
    cout<<"How much did the mouse weigh (lb)?\n";
    cin>>wgt_mouse;
    //Find ratio of sweetener to weight of mouse
    lethal_ratio_mouse=wgt_mouse/swtnr_kill_mouse;
    //Input weight of person
    cout<<"At what weight will you stop dieting (lb)?\n";
    cin>>wgt_dieter;
    //Compare ratio of lethal dose by weight
    lethal_ratio_person=wgt_dieter/lethal_ratio_mouse;
    //From ratio and percentage sweetener find amount of soda
    diet_soda=lethal_ratio_person/swtnr_pct;
    //Show one digit after decimal
    cout.setf(ios::fixed);
    cout.setf(ios::showpoint);
    cout.precision(1);
    //Output lethal dose
    cout<<"The lethal dose is "<<diet_soda<<" ounces of soda.\n";
    //Exit stage right
    return 0;
}

