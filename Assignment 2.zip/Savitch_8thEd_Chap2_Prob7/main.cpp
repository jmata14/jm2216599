/* 
 * File:   main.cpp
 * Author: Jesus Mata
 * Created on January 21, 2014, 9:21 PM
 * Calculate the net pay.
 */

//System Libraries
#include <iostream>
using namespace std;

//Global Constants
const int CNV_PRC=100;

//Function Prototypes

//Execution begins here!
int main(int argc, char** argv){
    //Declare variables
    const double rate=16.78;
    int hours,uni_wthldng=10, dependents, 
        dep_wthldng=35;
    double gross_pay, ss_wthldng,
           fed_wthldng, st_wthldng,net_pay;
    //Input hours worked
    cout<<"How many hours did you work?";
    cin>>hours;
    //Input dependents
    cout<<"How many dependents do you have?";
    cin>>dependents;
    //Calculate gross pay
    if(hours>40)
        gross_pay=rate*40+1.5*rate*(hours-40);
    else
        gross_pay=rate*40;
    
    //Calculate withholdings
    ss_wthldng=gross_pay*6/CNV_PRC;
    fed_wthldng=gross_pay*14/CNV_PRC;
    st_wthldng=gross_pay*5/CNV_PRC;
    //Set number of digits after decimal point
    cout.setf(ios::fixed);
    cout.setf(ios::showpoint);
    cout.precision(2);
    //calculate withholdings based on dependents
    if(dependents<3){
        net_pay=gross_pay-ss_wthldng-fed_wthldng-st_wthldng-uni_wthldng;
        cout<<"The net pay is $"<<net_pay<<endl;
        cout<<"The social security withholding is $"<<ss_wthldng<<endl;
        cout<<"The federal tax withholding is $"<<fed_wthldng<<endl;
        cout<<"The state tax withholding is $"<<st_wthldng<<endl;
        cout<<"The union dues are $"<<uni_wthldng<<endl;
    }
    else{
        net_pay=gross_pay-ss_wthldng-fed_wthldng-st_wthldng-uni_wthldng
                -dep_wthldng;
        cout<<"The net pay is $"<<net_pay<<endl;
        cout<<"The social security withholding is $"<<ss_wthldng<<endl;
        cout<<"The federal tax withholding is $"<<fed_wthldng<<endl;
        cout<<"The state tax withholding is $"<<st_wthldng<<endl;
        cout<<"The union dues are $"<<uni_wthldng<<endl;
        cout<<"The extra health insurance charge is $"<<dep_wthldng<<endl;
    }
    //Exit stage right
    return 0;
}


